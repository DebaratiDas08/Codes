/*eslint-env node*/

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------

// This application uses express as its web server
// for more info, see: http://expressjs.com
var express = require('express');
var http = require('http')
// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

// create a new express server
var app = express();
var bodyParser = require('body-parser')
// serve the files out of ./public as our main files
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();
app.post('/createWebhook',function(request,response)
{
var createWebhookOptions = {
  "method": "POST",
  "hostname": "api.box.com",
  "port": 443,
  "path": '/2.0/webhooks',
  "headers": {
    "authorization": "Bearer NBJ79b27Y4Otn8BGZK4UqZg39OdW2rsI",
    "Content-Type":"application-json"
  },
  "data":'{"target": {"id": "9212857305", "type": "folder"}, "address": "https://webhooknotificationforbox.mybluemix.net/getNotification", "triggers": ["FILE.UPLOADED","FILE.DOWNLOADED"]}'
  }
	http.post(createWebhookOptions,function(responseData)
	{

		response.send(responseData)
	})
})
app.post('/getNotification',function(request,response)
{
  console.log("url called")
	//console.log("resquest headers",(request.headers))
  console.log("request object",(request.body))
 //  var responseData = response
	// console.log("responseData.created_by",responseData.created_by)
})
// start server on the specified port and binding host
app.listen(appEnv.port, '0.0.0.0', function() {
  // print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});
