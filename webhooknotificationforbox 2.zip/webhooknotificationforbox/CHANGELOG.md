## Feb 2, 2016
- Change engine to Node v4.2
- Change express version to 4.13

## Nov 16, 2015
- Added changelog
